<?php
include "fonctions.php";

// r�cup�ration du param�tre "operation"
$operation = filter_input(INPUT_POST, 'operation', FILTER_SANITIZE_STRING);
$cnx = null;

// contr�le si le param�tre contient une information
if($operation != ""){
	try{
		$cnx = connexionPDO();
		switch($operation){
			case "dernier" : dernier(); break;
			case "enreg" : enreg(); break;
			case "tous" : tous(); break;
			case "suppr" : suppr(); break;
		}
	}catch(Exception $e){
		reponse("500", "erreur", $e->getMessage());
	}
}

/**
 * demande de r�cup�ration du dernier profil
 */
function dernier(){
	try{
		global $cnx;
		$req = $cnx->prepare("select * from profil order by datemesure desc");
		$req->execute();
		// s'il y a un profil, r�cup�ration du premier
		if($ligne = $req->fetch(PDO::FETCH_ASSOC)){
			reponse("200", "dernier", $ligne);
		}else{
			reponse("200", "dernier", "");
		}
	}catch(PDOException $e){
		reponse("400", "erreur", $e->getMessage());
	}	
}

/**
 * demande de r�cup�ration de tous les profils
 */
function tous(){
	try{
		global $cnx;
		$req = $cnx->prepare("select * from profil order by datemesure desc");
		$req->execute();
		// boucle sur le curseur pour r�cup�rer tous les profils
		$resultat = [];
		while($ligne = $req->fetch(PDO::FETCH_ASSOC)){
			$resultat[]= $ligne;
		}
		if(count($resultat) > 0){
			reponse("200", "tous", $resultat);
		}else{
			reponse("200", "tous", "");
		}
	}catch(PDOException $e){
		reponse("400", "erreur", $e->getMessage());
	}	
}

/**
 * enregistrement nouveau profil
 */
function enreg(){
	try{
		global $cnx;
		// r�cup�ration du param�tre "lesdonnees"
		$lesdonnees = filter_input(INPUT_POST, 'lesdonnees', FILTER_SANITIZE_STRING,FILTER_FLAG_NO_ENCODE_QUOTES);	
		$donnee = json_decode($lesdonnees);
		// insertion dans la BD
		$larequete = "insert into profil (datemesure, poids, taille, age, sexe)";
		$larequete .= " values (:datemesure, :poids, :taille, :age, :sexe)";
		$req = $cnx->prepare($larequete);
		if($donnee != null){
			foreach($donnee as $key => &$value){				
				$req->bindParam(":$key", $value);				
			}
		}	
		$result = $req->execute();
		// retour du r�sultat
		if($result == true){
			reponse("200", "enreg", $result);
		}else{
			reponse("400", "erreur", "erreur de requete");
		}
	}catch(PDOException $e){
		reponse("400", "erreur", $e->getMessage());
	}	
}
	
/**
 * suppression d'un profil
 */
function suppr(){
	try{
		global $cnx;
		// r�cup�ration du param�tre "lesdonnees"
		$lesdonnees = filter_input(INPUT_POST, 'lesdonnees', FILTER_SANITIZE_STRING,FILTER_FLAG_NO_ENCODE_QUOTES);	
		$donnee = json_decode($lesdonnees);
		// suppression dans la BDD
		$larequete = "delete from profil where datemesure = :datemesure";
		$req = $cnx->prepare($larequete);
		$req->bindParam(":datemesure", $donnee->datemesure);	
		$result = $req->execute();
		// retour du r�sultat
		if($result == true){
			reponse("200", "enreg", $result);
		}else{
			reponse("400", "erreur", "erreur de requete");
		}
	}catch(PDOException $e){
		reponse("400", "erreur", $e->getMessage());
	}	
}
	
/**
 * r�ponse renvoy�e (affich�e) au client au format json
 * @param int $code code standard HTTP
 * @param string $message 
 * @param array $result r�sultat de la demande 
 */
function reponse($code, $message, $result=""){
	$retour = array(
		'code' => $code,
		'message' => $message,
		'result' => $result
	);
	echo json_encode($retour, JSON_UNESCAPED_UNICODE);
}
	