-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 07 sep. 2023 à 14:56
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : coach
--

-- --------------------------------------------------------

--
-- Structure de la table profil
--

DROP TABLE IF EXISTS profil;
CREATE TABLE IF NOT EXISTS profil (
  datemesure datetime NOT NULL,
  poids int NOT NULL,
  taille int NOT NULL,
  age int NOT NULL,
  sexe int NOT NULL,
  PRIMARY KEY (datemesure)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table profil
--

INSERT INTO profil (datemesure, poids, taille, age, sexe) VALUES
('2023-07-11 08:55:44', 67, 165, 35, 0),
('2023-07-28 14:01:26', 45, 160, 55, 0),
('2023-07-28 14:00:43', 25, 150, 35, 1),
('2023-07-15 16:14:30', 70, 170, 60, 1),
('2023-07-14 12:49:30', 180, 160, 30, 1),
('2023-07-15 14:56:54', 202, 182, 32, 1),
('2023-07-28 13:56:35', 25, 175, 35, 1),
('2023-07-13 17:07:25', 30, 180, 20, 0),
('2023-07-13 17:06:57', 45, 180, 20, 0),
('2023-07-13 17:06:28', 45, 180, 20, 1),
('2023-07-13 17:06:07', 40, 180, 50, 1),
('2023-07-13 17:05:38', 65, 170, 35, 1),
('2023-07-13 17:04:41', 70, 150, 25, 0),
('2023-07-12 16:14:56', 45, 160, 35, 0),
('2023-07-12 16:13:45', 35, 180, 20, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
