<?php
header('Content-Type: application/json');

include_once("Controle.php");

$controle = new Controle();

// récupération des données
// Nom de la table
$table = filter_input(INPUT_GET, 'table', FILTER_SANITIZE_STRING) ??
         filter_input(INPUT_POST, 'table', FILTER_SANITIZE_STRING);
// nom et valeur des champs au format json
$champs = filter_input(INPUT_GET, 'champs', FILTER_SANITIZE_STRING,FILTER_FLAG_NO_ENCODE_QUOTES) ??
           filter_input(INPUT_POST, 'champs', FILTER_SANITIZE_STRING,FILTER_FLAG_NO_ENCODE_QUOTES);

$id = null;
if($champs != ""){
   $champs = json_decode($champs, true);
   // id (datemesure)
   $id = $champs["datemesure"];
}

// traitement suivant le verbe HTTP utilisé
switch($_SERVER['REQUEST_METHOD']){
	case 'GET':
		$controle->get($table, $id);
		break;
	case 'POST':
		$controle->post($table, $champs);
		break;
	case 'PUT':
		$controle->put($table, $id, $champs);
		break;
	case 'DELETE':
		$controle->delete($table, $id);
		break;
}
